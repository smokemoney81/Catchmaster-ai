import React from 'react';
import { View, Text } from 'react-native';

export default function CatchLogScreen() {
  return (
    <View style={{ flex: 1 }}>
      <Text>Dein Fangbuch</Text>
    </View>
  );
}