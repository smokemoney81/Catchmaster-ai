import React from 'react';
import { View, Text } from 'react-native';

export default function MapScreen() {
  return (
    <View style={{ flex: 1 }}>
      <Text>Karte mit Angelspots hier</Text>
    </View>
  );
}