import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Assistant() {
  return (
    <View style={styles.assistant}>
      <Text>🎣 Frag mich was zum Angeln!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  assistant: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 10,
    elevation: 5
  }
});