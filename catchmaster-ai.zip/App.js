import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import MapScreen from './screens/MapScreen';
import HomeScreen from './screens/HomeScreen';
import CatchLogScreen from './screens/CatchLogScreen';
import SettingsScreen from './screens/SettingsScreen';
import Assistant from './components/Assistant';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Map" component={MapScreen} />
        <Tab.Screen name="Fangbuch" component={CatchLogScreen} />
        <Tab.Screen name="Einstellungen" component={SettingsScreen} />
      </Tab.Navigator>
      <Assistant />
    </NavigationContainer>
  );
}